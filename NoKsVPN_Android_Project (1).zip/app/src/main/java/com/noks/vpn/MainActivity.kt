package com.noks.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var button: Button
    private var connected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 35, 28, 25)
            setBackgroundColor(Color.rgb(9, 6, 15))
        }

        val logo = TextView(this).apply {
            text = "NoKs"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = 1
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, 70))

        val subtitle = TextView(this).apply {
            text = "VPN"
            textSize = 15f
            setTextColor(Color.rgb(167, 139, 250))
            gravity = 1
        }
        root.addView(subtitle)

        status = TextView(this).apply {
            text = "Не подключено"
            textSize = 17f
            setTextColor(Color.LTGRAY)
            gravity = 1
        }
        val sp = LinearLayout.LayoutParams(-1, 80)
        sp.topMargin = 35
        root.addView(status, sp)

        button = Button(this).apply {
            text = "ПОДКЛЮЧИТЬСЯ"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = getDrawable(com.noks.vpn.R.drawable.button)
            setOnClickListener { toggleVpn() }
        }
        val bp = LinearLayout.LayoutParams(-1, 62)
        bp.topMargin = 25
        root.addView(button, bp)

        val server = TextView(this).apply {
            text = "🌍 Сервер\nАвтоматический"
            textSize = 17f
            setTextColor(Color.WHITE)
            background = getDrawable(com.noks.vpn.R.drawable.bg)
            setPadding(25, 18, 25, 18)
        }
        val vp = LinearLayout.LayoutParams(-1, 90)
        vp.topMargin = 35
        root.addView(server, vp)

        val info = TextView(this).apply {
            text = "\nNoKs VPN\nВерсия 1.0\n\nДля настоящего интернет-туннеля добавьте конфигурацию VPN-сервера в NoksVpnService.kt."
            textSize = 14f
            setTextColor(Color.GRAY)
            gravity = 1
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private fun toggleVpn() {
        if (!connected) {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                startActivityForResult(intent, 100)
            } else {
                startVpn()
            }
        } else {
            stopService(Intent(this, NoksVpnService::class.java))
            connected = false
            status.text = "Не подключено"
            button.text = "ПОДКЛЮЧИТЬСЯ"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        startService(Intent(this, NoksVpnService::class.java))
        connected = true
        status.text = "Подключено"
        button.text = "ОТКЛЮЧИТЬСЯ"
    }
}

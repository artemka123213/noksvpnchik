package com.noks.vpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class NoksVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Базовый Android VPN-интерфейс.
        // Здесь подключается реальный VLESS/WireGuard/другой VPN engine.
        if (vpnInterface == null) {
            vpnInterface = Builder()
                .setSession("NoKs VPN")
                .addAddress("10.8.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .setBlocking(false)
                .establish()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }
}
